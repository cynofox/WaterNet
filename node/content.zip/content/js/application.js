/* tooltip */
$(function(){
	$('.tip').popover()
});
/* /tooltip */

/* slider */
$('#foo').slider()
  .on('slide', function(ev){
     $('#bar').val(ev.value);
	 $('#bar1').text(ev.value);
  });
/* /slider */